"""Core application modules."""
