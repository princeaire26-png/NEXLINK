# NEXLINK Windows Client

`NEXLINK-Client.exe` is the unified Windows operator/endpoint application.

It contains:

- NEXLINK Command Center
- authenticated Python device agent
- remote desktop session viewer
- mouse/keyboard/clipboard/file-transfer channels
- device monitoring and inventory
- RMM alerts
- Network Guard
- AI diagnostics/planning interface
- automation interface
- Security Center
- Support Center
- local voucher/timed Internet access

Run it as Administrator on Windows because Network Guard requires elevated Windows Firewall/hosts access.

There is no separate agent executable and no separate InternetGuard executable.
